import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import AllTasks from './pages/AllTasks';
import Members from './pages/Members';
import MyBoards from './pages/MyBoards';
import SoftwareUpdates from './pages/SoftwareUpdates';
import UiUxDesign from './pages/UiUxDesign';
import WebDevelopment from './pages/WebDevelopment';
import MobileDevelopment from './pages/MobileDevelopment';
import Template from './pages/Template';
import Archive from './pages/Archive';
import Trash from './pages/Trash';
import Settings from './pages/Settings';

function App() {
  return (
    <Router>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/all-tasks" element={<AllTasks />} />
          <Route path="/members" element={<Members />} />
          <Route path="/my-boards" element={<MyBoards />} />
          <Route path="/software-updates" element={<SoftwareUpdates />} />
          <Route path="/ui-ux-design" element={<UiUxDesign />} />
          <Route path="/web-development" element={<WebDevelopment />} />
          <Route path="/mobile-development" element={<MobileDevelopment />} />
          <Route path="/template" element={<Template />} />
          <Route path="/archive" element={<Archive />} />
          <Route path="/trash" element={<Trash />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;