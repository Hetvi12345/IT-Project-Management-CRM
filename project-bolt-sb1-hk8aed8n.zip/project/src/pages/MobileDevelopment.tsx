import React from 'react';
import { PlusIcon, FilterIcon, ShareIcon } from 'lucide-react';

const MobileDevelopment = () => {
  return (
    <div className="flex-1 p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Mobile Development</h1>
          <p className="text-gray-600">Manage mobile development projects and tasks</p>
        </div>
        <div className="flex items-center space-x-4">
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <FilterIcon className="w-4 h-4 mr-2" />
            Filter
          </button>
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <ShareIcon className="w-4 h-4 mr-2" />
            Share
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" />
            New Project
          </button>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Mobile Development Projects</h2>
        <p className="text-gray-600">Your mobile development projects will appear here.</p>
      </div>
    </div>
  );
};

export default MobileDevelopment;