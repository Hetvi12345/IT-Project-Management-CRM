import React from 'react';
import { PlusIcon, FilterIcon, ShareIcon } from 'lucide-react';

const AllTasks = () => {
  const tasks = [
    {
      title: 'Add admin APIs for international pricing by country',
      type: 'Frontend Development',
      priority: 'Important',
      assignees: ['Jenny Wilson', 'Cody Fisher'],
      metrics: { points: 65, hours: 70 },
      status: 'In Progress'
    },
    {
      title: 'Integrate SSL web certificates into onboarding workflow',
      type: 'UX Design',
      priority: 'Important and urgent',
      assignees: ['Jerome Bell', 'Robert Fox'],
      metrics: { points: 52, hours: 56 },
      status: 'To Do'
    },
    {
      title: 'Analyze competitors and industry trends',
      type: 'Research',
      priority: 'Important',
      assignees: ['Sarah Johnson', 'Mike Brown'],
      metrics: { points: 45, hours: 40 },
      status: 'Completed'
    }
  ];

  return (
    <div className="flex-1 p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">All Tasks</h1>
          <p className="text-gray-600">View and manage all your tasks in one place</p>
        </div>

        <div className="flex items-center space-x-4">
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <FilterIcon className="w-4 h-4 mr-2" />
            Filter
          </button>
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <ShareIcon className="w-4 h-4 mr-2" />
            Share
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" />
            Add Task
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="grid grid-cols-1 gap-4 p-6">
          {tasks.map((task, index) => (
            <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    task.priority === 'Important and urgent' 
                      ? 'bg-red-100 text-red-600' 
                      : 'bg-yellow-100 text-yellow-600'
                  }`}>
                    {task.priority}
                  </span>
                  <span className="text-sm text-gray-600">{task.type}</span>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  task.status === 'Completed'
                    ? 'bg-green-100 text-green-600'
                    : task.status === 'In Progress'
                    ? 'bg-blue-100 text-blue-600'
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {task.status}
                </span>
              </div>
              <h3 className="font-medium text-lg mb-3">{task.title}</h3>
              <div className="flex justify-between items-center">
                <div className="flex -space-x-2">
                  {task.assignees.map((assignee, i) => (
                    <img
                      key={i}
                      className="w-8 h-8 rounded-full border-2 border-white"
                      src={`https://i.pravatar.cc/150?img=${i + 10}`}
                      alt={assignee}
                    />
                  ))}
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span>{task.metrics.points} pts</span>
                  <span>{task.metrics.hours}h</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AllTasks;