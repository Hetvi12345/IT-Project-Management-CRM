import React from 'react';
import { PlusIcon, FilterIcon, ShareIcon } from 'lucide-react';

const General = () => {
  return (
    <div className="flex-1 p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">General</h1>
          <p className="text-gray-600">Overview of your workspace</p>
        </div>
        <div className="flex items-center space-x-4">
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <FilterIcon className="w-4 h-4 mr-2" />
            Filter
          </button>
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <ShareIcon className="w-4 h-4 mr-2" />
            Share
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center">
            <PlusIcon className="w-4 h-4 mr-2" />
            New Item
          </button>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Workspace Overview</h2>
        <p className="text-gray-600">Your workspace overview will appear here.</p>
      </div>
    </div>
  );
};

export default General;