import React from 'react';
import { PlusIcon, FilterIcon, ShareIcon } from 'lucide-react';

const Dashboard = () => {
  const statuses = ['TO DO', 'WORK IN PROGRESS', 'UNDER REVIEW', 'COMPLETED'];
  const tasks = [
    {
      title: 'Add admin APIs for international pricing by country',
      type: 'Frontend Development',
      priority: 'Important',
      assignees: ['Jenny Wilson', 'Cody Fisher'],
      metrics: { points: 65, hours: 70 },
    },
    {
      title: 'Integrate SSL web certificates into onboarding workflow',
      type: 'UX Design',
      priority: 'Important and urgent',
      assignees: ['Jerome Bell', 'Robert Fox'],
      metrics: { points: 52, hours: 56 },
    },
  ];

  return (
    <div className="flex-1 p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Product Development ⭐</h1>
          <div className="flex items-center space-x-2">
            <span className="flex -space-x-2">
              {[1, 2, 3, 4].map((i) => (
                <img
                  key={i}
                  className="w-8 h-8 rounded-full border-2 border-white"
                  src={`https://i.pravatar.cc/150?img=${i}`}
                  alt={`Team member ${i}`}
                />
              ))}
            </span>
            <button className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <PlusIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <FilterIcon className="w-4 h-4 mr-2" />
            Filter
          </button>
          <button className="flex items-center px-4 py-2 border rounded-lg">
            <ShareIcon className="w-4 h-4 mr-2" />
            Share
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">
            New Board
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {statuses.map((status, index) => (
          <div key={index} className="bg-gray-100 rounded-lg p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">{status}</h3>
              <span className="bg-white px-2 py-1 rounded text-sm">3</span>
            </div>

            <div className="space-y-4">
              {tasks.map((task, taskIndex) => (
                <div key={taskIndex} className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center mb-2">
                    <span className="px-2 py-1 bg-red-100 text-red-600 rounded text-sm">
                      {task.priority}
                    </span>
                    <span className="ml-2 text-sm text-gray-600">{task.type}</span>
                  </div>
                  <h4 className="font-medium mb-3">{task.title}</h4>
                  <div className="flex justify-between items-center">
                    <div className="flex -space-x-2">
                      {task.assignees.map((assignee, i) => (
                        <img
                          key={i}
                          className="w-6 h-6 rounded-full border-2 border-white"
                          src={`https://i.pravatar.cc/150?img=${i + 10}`}
                          alt={assignee}
                        />
                      ))}
                    </div>
                    <div className="flex items-center space-x-3 text-sm text-gray-500">
                      <span>{task.metrics.points} pts</span>
                      <span>{task.metrics.hours}h</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;