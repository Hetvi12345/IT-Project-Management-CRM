import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FolderIcon, InboxIcon, UsersIcon, CogIcon, ArchiveIcon as ArchiveBoxIcon, TrashIcon } from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const menuItems = [
    { label: 'All Task', icon: InboxIcon, path: '/all-tasks' },
    { label: 'Members', icon: UsersIcon, path: '/members' },
    { label: 'My Boards', icon: FolderIcon, path: '/my-boards' },
    { label: 'Software Updates', icon: InboxIcon, path: '/software-updates' },
    { label: 'UI/UX Design', icon: InboxIcon, path: '/ui-ux-design' },
    { label: 'Web Development', icon: InboxIcon, path: '/web-development' },
    { label: 'Mobile Development', icon: InboxIcon, path: '/mobile-development' },
    { label: 'Template', icon: InboxIcon, path: '/template' },
    { label: 'Archive', icon: ArchiveBoxIcon, path: '/archive' },
    { label: 'Trash', icon: TrashIcon, path: '/trash' },
    { label: 'Settings', icon: CogIcon, path: '/settings' },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-4">
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">General</h2>
        <nav>
          {menuItems.slice(0, 3).map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg mb-1 ${
                location.pathname === item.path ? 'bg-gray-100' : ''
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Team Boards</h2>
        <nav>
          {menuItems.slice(3, 7).map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg mb-1 ${
                location.pathname === item.path ? 'bg-gray-100' : ''
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Appearance</h2>
        <nav>
          {menuItems.slice(7).map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg mb-1 ${
                location.pathname === item.path ? 'bg-gray-100' : ''
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;